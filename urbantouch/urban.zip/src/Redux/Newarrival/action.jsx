import axios from "axios";
import * as types from "./actionTypes";

// export const GET_NEWARRIVAL = "GET_NEWARRIVAL";
// export const GET_NEWARRIVAL_SUCCESS = "GET_NEWARRIVAL_SUCCESS";
// export const GET_NEWARRIVAL_FAILURE = "GET_NEWARRIVAL_FAILURE";

export const getNewArrival = (payload) => ({
    type:types.GET_NEWARRIVAL,
    payload
});

export const getNewArrivalSuccess = (payload)=> ({
    type: types.GET_NEWARRIVAL_SUCCESS,
    payload
   
});

export const getNewArrivalFailure = (payload)=> ({
    type: types.GET_NEWARRIVAL_FAILURE,
    payload
});

export const getMensData =(payload)=>{
    return (dispatch) => {
        dispatch(getNewArrival());
        axios.get(`http://localhost:8080/newarrival`,{
            params:{
                ...payload,
            }
        })
            .then(response => {
                dispatch(getNewArrivalSuccess(response.data));
               // console.log("raj",response.data);
            }).catch(error => {
                dispatch(getNewArrivalFailure(error));
            }
        );
    }
    }
 
    
    export const getMensFilterData = (x) => {
        return (dispatch) => {
                dispatch( getNewArrival());
                axios.get(`https://urban-touch-0181.herokuapp.com/mens`)
                .then(res => {

                        if(x==1){
                                dispatch(getNewArrival(res.data.filter(y => y.price < 100)))
                        }
                        else if(x==2){
                                dispatch(getNewArrival(res.data.filter(y => y.price >= 100 && y.price < 300)))
                        }
                        else if(x==3){
                                dispatch(getNewArrival(res.data.filter(y => y.price >= 300 && y.price < 500)))
                        }
                        else if(x==4){
                                dispatch(getNewArrival(res.data.filter(y => y.price >= 500)))
                        }
                }
                )
                .catch(err => {dispatch(getNewArrivalFailure(err))}
                )
        }
}
    