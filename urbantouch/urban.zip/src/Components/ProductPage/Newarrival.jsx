import React, { useEffect, useState } from 'react'
import { useDispatch ,useSelector} from 'react-redux';
import { NavLink, useNavigate } from "react-router-dom";
import {  getMensData,getNewArrival,getMensFilterData} from '../../Redux/Newarrival/action';
import  "../ProductPage/Newarrival.css";
import Productdetail from './Productdetail';

export default function Newarrival() {
    const [data,setdata] = useState([]);

    const dispatch = useDispatch();
    const navigate = useNavigate();
    const products = useSelector( store =>  store.newarrivalreducer.products);
 
    // const {loading,error} = useSelector( store =>  store.newarrival);

    useEffect(() => {
        dispatch(getMensData());
    },[dispatch.products?.length]);
    console.log("prop",products)

// ------------sorting and filter functionality-----------------//
const handleChangeprice = (val) => {
  if (val === 1) {
    const x = products.sort((a, b) => {
      return b.price - a.price;
    });
    setdata([...x]); // this is to update the state
    dispatch(getNewArrival(x));
  } else if (val === 2) {
    const x = products.sort((a, b) => {
      return a.price - b.price;
    });
    setdata([...x]);
    // dispatch(getmens(x))
  }
};


const handleChangename = (val) => {
  if (val === "ase") {
    const x = products.sort((a, b) => {
      return a.name.localeCompare(b.name);
    });
    setdata([...x]);
  } else if (val === "des") {
    const x = products.sort((a, b) => {
      return b.name.localeCompare(a.name);
    });
    setdata([...x]);
  }
};

const handlefilter = (val) => {
  if (val === 1) {
    const x = products.filter((item) => {
      return item.price <= 100;
    });
    dispatch(getMensFilterData(1));
  } else if (val === 2) {
    const x = products.filter((item) => {
      return item.price > 100 && item.price <= 300;
    });
    dispatch(getMensFilterData(2));
  } else if (val === 3) {
    const x = products.filter((item) => {
      return item.price >= 300;
    });
    dispatch(getMensFilterData(3));
  }else if (val === 4) {
    const x = products.filter((item) => {
      return item.price >= 300;
    });
    dispatch(getMensFilterData(4));
  }
};









  return (
    <div>
      
    <h1 className='heading'>NEW ARRIVALS</h1>

    <div >
      <div className="filter"  >
        <div className="filter-price">
          <h3>Filter by price</h3>
          <div className="filter-price-btn">
            <button
              onClick={(e) => {
                handleChangeprice(e.target.value);
              }
              }
              className="filter-price-btn-1"
            >
              High to low
            </button>
            <button

              onClick={() => {
                handleChangeprice(2);
              }
              }
              className="filter-price-btn-2"
            >
              Low to high
            </button>
              

               </div>
           </div>
        </div>
    </div>
    <div className='newarrivalcontain'> 

    
           {
                products.map((product,index)=>{
                    return(
                        <div key={index}>
                        
                                <NavLink to={`/${"newarrival"}/${product.id}`}>
                                <img src={product.image} alt="" className='newimg'/>
                                
                                </NavLink>
                        
                                <h3>{product.title}</h3>
                                <p>{product.price}</p>
                        
                        
                        </div>
                    )
                })
              }
      

    
    </div>
    
    </div>
  )}