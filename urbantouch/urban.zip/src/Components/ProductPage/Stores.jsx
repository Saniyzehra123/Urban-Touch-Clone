import React from 'react'

export default function Stores() {


  return (
    <div>
      <h2> Store</h2>
   
   <div>
    <input  type= "text" placeholder="Type a postcode and address"/>
   </div>
   {/* <img src="https://images.unsplash.com/photo-1518791841217-8f162f1e1131?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60" alt=""/> */}
 

    </div>
  )
}
